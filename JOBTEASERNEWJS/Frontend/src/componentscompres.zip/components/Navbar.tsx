import React from "react";
import { Link } from "react-router-dom";
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faUser } from '@fortawesome/free-solid-svg-icons';
import { faFileAlt } from '@fortawesome/free-solid-svg-icons';
import { faBriefcase } from '@fortawesome/free-solid-svg-icons';

const Navbar: React.FC = () => {
  return (
    <nav style={styles.navbar}>
      <ul style={styles.navList}>
        <li style={styles.navItem}>
          <Link to="/" style={styles.navLink}><FontAwesomeIcon icon={faBriefcase} style={styles.icon} /></Link>
        </li>
        <li style={styles.navItem}>
          <Link to="/applications" style={styles.navLink}><FontAwesomeIcon icon={faFileAlt} style={styles.icon} /></Link>
        </li>
        <li style={styles.navItem}>
          <Link to="/profile" style={styles.navLink}><FontAwesomeIcon icon={faUser} style={styles.icon} /></Link>
        </li>
      </ul>
    </nav>
  );
};

const styles = {
  navbar: {
    background: '#b22180',
    padding: "20px 0",
    width: "100%",
    position: "fixed" as "fixed",
    top: 0,
    left: 0,
    zIndex: 1000,
    boxShadow: "0 4px 10px rgba(0, 0, 0, 0.2)",
  },
  icon: {
    fontSize: '1.5rem',
    color: '#fff',
  },
  navList: {
    listStyleType: "none",
    display: "flex",
    justifyContent: "center" as "center",
    margin: 0,
    padding: 0,
    gap: "40px",
  },
  navItem: {
    fontSize: "1.2rem",
  },
  navLink: {
    color: "#fff",
    textDecoration: "none",
    padding: "10px 20px",
    borderRadius: "5px",
    transition: "background-color 0.3s ease",
  },
};

export default Navbar;
